sap.ui.define([
	"smartstorylayout/smartstorylayout/test/unit/controller/demoview.controller"
], function () {
	"use strict";
});