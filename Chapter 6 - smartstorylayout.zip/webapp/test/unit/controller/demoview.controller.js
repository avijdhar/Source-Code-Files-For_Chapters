/*global QUnit*/

sap.ui.define([
	"smartstorylayout/smartstorylayout/controller/demoview.controller"
], function (oController) {
	"use strict";

	QUnit.module("demoview Controller");

	QUnit.test("I should test the demoview controller", function (assert) {
		var oAppController = new oController();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});