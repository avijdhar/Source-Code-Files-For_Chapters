var main_filedata = {
    "lib\\SampleProject\\Services\\GeneralServices.xsodata": {
        "container": "xsjs",
        "fileIndex": 0
    },
    "src\\SampleProject\\TableDefinition\\TBL.hdbcds": {
        "container": "db",
        "fileIndex": 1
    },
    "resources\\SampleProject\\ui\\index.html": {
        "container": "web",
        "fileIndex": 2
    },
    "resources\\SampleProject\\ui\\indexUI5.html": {
        "container": "web",
        "fileIndex": 3
    },
    "lib\\SampleProject\\ui\\logic.xsjs": {
        "container": "xsjs",
        "fileIndex": 4
    },
    "resources\\SampleProject\\ui\\style.css": {
        "container": "web",
        "fileIndex": 5
    },
    "resources\\SampleProject\\ui\\images\\Contact_hover.png": {
        "container": "web",
        "fileIndex": 6
    },
    "resources\\SampleProject\\ui\\images\\Contact_regular.png": {
        "container": "web",
        "fileIndex": 7
    },
    "resources\\SampleProject\\ui\\images\\SAPLogo.gif": {
        "container": "web",
        "fileIndex": 8
    },
    "C:\\HANA\\xsa\\Migrated\\db\\src\\Models\\SalesDetail.hdbcalculationview": {
        "container": "db",
        "fileIndex": 9
    },
    "src\\SampleProject\\Models\\SalesDetail.hdbcalculationview.properties": {
        "container": "db",
        "fileIndex": 10
    }
};