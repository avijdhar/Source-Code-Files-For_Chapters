var main_filelist = [
    {
        "name": "xsjs\\lib\\SampleProject\\Services\\GeneralServices.xsodata",
        "pkgOnlyName": "\\SampleProject\\Services\\GeneralServices.xsodata",
        "ext": "xsodata",
        "container": "xsjs",
        "index": 0
    },
    {
        "name": "db\\src\\SampleProject\\TableDefinition\\TBL.hdbcds",
        "pkgOnlyName": "\\SampleProject\\TableDefinition\\TBL.hdbcds",
        "ext": "hdbcds",
        "container": "db",
        "index": 1
    },
    {
        "name": "web\\resources\\SampleProject\\ui\\index.html",
        "pkgOnlyName": "\\SampleProject\\ui\\index.html",
        "ext": "html",
        "container": "web",
        "index": 2
    },
    {
        "name": "web\\resources\\SampleProject\\ui\\indexUI5.html",
        "pkgOnlyName": "\\SampleProject\\ui\\indexUI5.html",
        "ext": "html",
        "container": "web",
        "index": 3
    },
    {
        "name": "xsjs\\lib\\SampleProject\\ui\\logic.xsjs",
        "pkgOnlyName": "\\SampleProject\\ui\\logic.xsjs",
        "ext": "xsjs",
        "container": "xsjs",
        "index": 4
    },
    {
        "name": "web\\resources\\SampleProject\\ui\\style.css",
        "pkgOnlyName": "\\SampleProject\\ui\\style.css",
        "ext": "css",
        "container": "web",
        "index": 5
    },
    {
        "name": "web\\resources\\SampleProject\\ui\\images\\Contact_hover.png",
        "pkgOnlyName": "\\SampleProject\\ui\\images\\Contact_hover.png",
        "ext": "png",
        "container": "web",
        "index": 6
    },
    {
        "name": "web\\resources\\SampleProject\\ui\\images\\Contact_regular.png",
        "pkgOnlyName": "\\SampleProject\\ui\\images\\Contact_regular.png",
        "ext": "png",
        "container": "web",
        "index": 7
    },
    {
        "name": "web\\resources\\SampleProject\\ui\\images\\SAPLogo.gif",
        "pkgOnlyName": "\\SampleProject\\ui\\images\\SAPLogo.gif",
        "ext": "gif",
        "container": "web",
        "index": 8
    },
    {
        "name": "db\\C:\\HANA\\xsa\\Migrated\\db\\src\\Models\\SalesDetail.hdbcalculationview",
        "pkgOnlyName": "HANA\\xsa\\Migrated\\db\\src\\Models\\SalesDetail.hdbcalculationview",
        "ext": "hdbcalculationview",
        "container": "db",
        "index": 9
    },
    {
        "name": "db\\src\\SampleProject\\Models\\SalesDetail.hdbcalculationview.properties",
        "pkgOnlyName": "\\SampleProject\\Models\\SalesDetail.hdbcalculationview.properties",
        "ext": "properties",
        "container": "db",
        "index": 10
    }
];