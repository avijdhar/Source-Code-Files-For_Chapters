var main_data = {
    "sum": [
        {
            "name": "total",
            "number": 17
        },
        {
            "name": "xsjs",
            "number": 2,
            "detail": {
                ".xsodata": 1,
                ".xsjs": 1
            }
        },
        {
            "name": "db",
            "number": 5,
            "detail": {
                ".calculationview": 2,
                ".hdbrole": 1,
                ".hdbschema": 1,
                ".hdbdd": 1
            }
        },
        {
            "name": "web",
            "number": 6,
            "detail": {
                ".html": 2,
                ".css": 1,
                ".png": 2,
                ".gif": 1
            }
        },
        {
            "name": "todo",
            "number": 2,
            "detail": {
                ".xsaccess": 2
            }
        },
        {
            "name": "delete",
            "number": 2,
            "detail": {
                ".project": 1,
                ".xsapp": 1
            }
        }
    ],
    "errors": {
        "number": 0,
        "list": []
    },
    "warnings": {
        "number": 3,
        "list": [
            {
                "type": "WARNING",
                "message": [
                    "CORS is currently not supported by configuration"
                ],
                "description": "With XS Advanced it is currently not possible to configure CORS centrally. You have to set the required headers manually in every involved response.",
                "category": "SECURITY",
                "id": "SECURITY_14",
                "file": "migration\\orig-src\\SampleProject\\.xsaccess"
            },
            {
                "type": "WARNING",
                "message": [
                    "Features in xsaccess can only be partially migrated to new XS Advanced security concept (xsjs/xs-app.json). Check migration guide for detail."
                ],
                "description": "Check the security migration guide",
                "category": "SECURITY",
                "id": "SECURITY_2",
                "file": "migration\\orig-src\\SampleProject\\.xsaccess"
            },
            {
                "type": "WARNING",
                "message": [
                    "Features in xsaccess can only be partially migrated to new XS Advanced security concept (xsjs/xs-app.json). Check migration guide for detail."
                ],
                "description": "Check the security migration guide",
                "category": "SECURITY",
                "id": "SECURITY_2",
                "file": "migration\\orig-src\\SampleProject\\ui\\.xsaccess"
            }
        ]
    },
    "infos": {
        "number": 3,
        "list": [
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".project"
                ],
                "description": "The object type has not been migrated and is not relevant anymore for XS Advanced projects. There is no loss in functionality",
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "migration\\orig-src\\SampleProject\\.project"
            },
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".xsapp"
                ],
                "description": "The object type has not been migrated and is not relevant anymore for XS Advanced projects. There is no loss in functionality",
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "migration\\orig-src\\SampleProject\\.xsapp"
            },
            {
                "type": "INFO",
                "message": [
                    "{0} file is no longer needed in XS Advanced projects.",
                    ".hdbschema"
                ],
                "description": "The object type has not been migrated and is not relevant anymore for XS Advanced projects. There is no loss in functionality",
                "category": "DELETE",
                "id": "DELETE_1",
                "file": "migration\\orig-src\\SampleProject\\TableDefinition\\PROJECT_SCHEMA.hdbschema"
            }
        ]
    },
    "steps": [
        {
            "priority": 4,
            "always-shown": true,
            "name": "Migration of Security Concept Required",
            "desc": "The security concept has changed with XS Advanced and is incompatible with XS Classic. Manual migration steps are required in order to complete the migration of this application to XS Advanced. <br>For information about the XS Advanced security concept read the XS Advanced Migration Guide.",
            "link": {
                "info": "description",
                "url": "undefined#security"
            },
            "messages": {
                "WARNING": [
                    {
                        "type": "WARNING",
                        "message": [
                            "CORS is currently not supported by configuration"
                        ],
                        "description": "With XS Advanced it is currently not possible to configure CORS centrally. You have to set the required headers manually in every involved response.",
                        "category": "SECURITY",
                        "id": "SECURITY_14",
                        "file": "migration\\orig-src\\SampleProject\\.xsaccess"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Features in xsaccess can only be partially migrated to new XS Advanced security concept (xsjs/xs-app.json). Check migration guide for detail."
                        ],
                        "description": "Check the security migration guide",
                        "category": "SECURITY",
                        "id": "SECURITY_2",
                        "file": "migration\\orig-src\\SampleProject\\.xsaccess"
                    },
                    {
                        "type": "WARNING",
                        "message": [
                            "Features in xsaccess can only be partially migrated to new XS Advanced security concept (xsjs/xs-app.json). Check migration guide for detail."
                        ],
                        "description": "Check the security migration guide",
                        "category": "SECURITY",
                        "id": "SECURITY_2",
                        "file": "migration\\orig-src\\SampleProject\\ui\\.xsaccess"
                    }
                ]
            },
            "list": [
                {
                    "text": "WARNING",
                    "value": 3
                }
            ]
        },
        {
            "priority": 11,
            "name": "Objects Which Have Not Been Migrated",
            "desc": "The following objects have not been migrated because they are either not relevant anymore or have been successfully migrated to another object type.",
            "link": {
                "info": "description",
                "url": "undefined#delete"
            },
            "messages": {
                "INFO": [
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".project"
                        ],
                        "description": "The object type has not been migrated and is not relevant anymore for XS Advanced projects. There is no loss in functionality",
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "migration\\orig-src\\SampleProject\\.project"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".xsapp"
                        ],
                        "description": "The object type has not been migrated and is not relevant anymore for XS Advanced projects. There is no loss in functionality",
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "migration\\orig-src\\SampleProject\\.xsapp"
                    },
                    {
                        "type": "INFO",
                        "message": [
                            "{0} file is no longer needed in XS Advanced projects.",
                            ".hdbschema"
                        ],
                        "description": "The object type has not been migrated and is not relevant anymore for XS Advanced projects. There is no loss in functionality",
                        "category": "DELETE",
                        "id": "DELETE_1",
                        "file": "migration\\orig-src\\SampleProject\\TableDefinition\\PROJECT_SCHEMA.hdbschema"
                    }
                ]
            },
            "list": [
                {
                    "text": "INFO",
                    "value": 3
                }
            ]
        }
    ],
    "task": {
        "dus": [],
        "packages": [
            "SampleProject",
            "SampleProject.Models",
            "SampleProject.Roles",
            "SampleProject.Services",
            "SampleProject.TableDefinition",
            "SampleProject.ui",
            "SampleProject.ui.images"
        ]
    },
    "project": {
        "name": "SampleProject",
        "vendor": "No-vendor",
        "version": "0",
        "description": ""
    },
    "cmdline": "--h \"false\" --help \"false\" --generate-manifests \"false\" --zip \"false\" --hta \"false\" --generate-providers \"false\" --unhide-hidden-columns \"false\" --generate-local-slash-synonyms \"false\" --integrated-synonymtargets \"false\" --target-dir \"C:\\HANA\\xsa\\Migrated\" --packages \"SampleProject\"",
    "isoTime": "2018-10-03T07:06:48.551Z",
    "mig-tool-version": "1.0.11",
    "system": {
        "host": "localhost",
        "port": "30015",
        "user": "GVB",
        "sid": "IMI",
        "hana_version": "1.00.122.08.1490178281"
    }
};